/*
--------------------------------------------------
Project: a3q1
File:    mystring.h
Author:  Sushant Sah
Version: 2025-01-31
--------------------------------------------------
*/ 

#ifndef MYSTRING_H
#define MYSTRING_H

int str_words(char *s);

int str_lower(char *s);

void str_trim(char *s);

#endif